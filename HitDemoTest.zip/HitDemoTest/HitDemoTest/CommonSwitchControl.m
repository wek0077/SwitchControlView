//
//  CommonSwitchControl.m
//  Tupperware
//
//  Created by admin on 2018/6/12.
//  Copyright © 2018年 Tupperware. All rights reserved.
//

#import "CommonSwitchControl.h"

#define kThemeColor  [UIColor redColor]
#define kWordColor   [UIColor yellowColor]
#define kSelectColor [UIColor whiteColor]

@implementation CommonSwitchControl

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kThemeColor;
    }
    return self;
}

- (void)initView{
    UIFont *font = [UIFont systemFontOfSize:16.0];
    CGFloat width = self.underLineW;
    CGFloat startXvalue = (self.frame.size.width - width * self.buttonNumber) / (self.buttonNumber + 1);
    
    CGFloat height = self.frame.size.height - 1.5;
    CGFloat x = startXvalue;
    CGFloat y = 0;
    
    for (int i = 0; i< self.buttonNumber; i ++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(x + i * startXvalue + i *width, y+10, width, height);
        button.titleLabel.font = font;
        [button setTitle:self.buttonTitles[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor yellowColor] forState:UIControlStateNormal];
        [button setTag: (1000+ i)];
        [button addTarget:self action:@selector(switchTitle:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
    }
    
    
    height = 1.5;
    y = self.frame.size.height - 1.5;
    self.selectedView = [[UIView alloc] initWithFrame:CGRectMake(startXvalue, y, width, height)];
    self.selectedView.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.selectedView];
    
    self.selectedView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
}

- (void)switchTitle:(UIButton *)button
{
    self.currentIndex = button.tag - 1000;
    
    UIButton *selectedButton = button;
    
    if (selectedButton) {
        [UIView animateWithDuration:0.2 animations:^{
            [selectedButton setTitleColor:kSelectColor forState:UIControlStateNormal];
            
            CGFloat width = self.selectedView.frame.size.width;
            CGFloat height = self.selectedView.frame.size.height;
            CGFloat startXvalue = (self.frame.size.width - width * self.buttonNumber) / (self.buttonNumber + 1);
            CGFloat x = startXvalue + (selectedButton.tag - 1000) * startXvalue + (selectedButton.tag - 1000) * self.underLineW;
            CGFloat y = self.selectedView.frame.origin.y;
            self.selectedView.frame = CGRectMake(x, y, width, height);
        }];
    }
    [self.delegate switchButton:(selectedButton.tag - 1000)];
}

- (void)setCurrentIndex:(NSInteger)currentIndex {
    _currentIndex = currentIndex;
    NSInteger tag = 1000 + currentIndex;
    UIButton *selectedButton = (UIButton *)[self viewWithTag:tag];
    
    for (int i = 0; i<self.buttonNumber; i ++) {
        NSInteger tag = 1000 + i;
        UIButton *everybutton = (UIButton *)[self viewWithTag:tag];
        [everybutton setTitleColor:kWordColor forState:UIControlStateNormal];
    }
    
    if (selectedButton) {
        [UIView animateWithDuration:0.2 animations:^{
            [selectedButton setTitleColor:kSelectColor forState:UIControlStateNormal];
            
            CGFloat width = self.selectedView.frame.size.width;
            CGFloat height = self.selectedView.frame.size.height;
            CGFloat startXvalue = (self.frame.size.width - width * self.buttonNumber) / (self.buttonNumber + 1);
            CGFloat x = startXvalue + (selectedButton.tag - 1000) * startXvalue + (selectedButton.tag - 1000) * self.underLineW;
            CGFloat y = self.selectedView.frame.origin.y;
            self.selectedView.frame = CGRectMake(x, y, width, height);
        }];
    }
}

@end
