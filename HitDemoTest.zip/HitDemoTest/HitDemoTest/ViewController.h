//
//  ViewController.h
//  HitDemoTest
//
//  Created by admin on 2018/6/12.
//  Copyright © 2018年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CommonSwitchControl.h"

@interface ViewController : UIViewController


@property (nonatomic, strong) CommonSwitchControl *switchView;


@end

