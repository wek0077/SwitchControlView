//
//  CommonSwitchControl.h
//  Tupperware
//
//  Created by admin on 2018/6/12.
//  Copyright © 2018年 Tupperware. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CommonSwitchControlDelegate <NSObject>

- (void)switchButton:(NSInteger )buttonNumber;


@end

@interface CommonSwitchControl : UIView

@property (nonatomic, strong) UIView *selectedView;

@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, assign) NSInteger underLineW;
@property (nonatomic, assign) NSInteger buttonNumber;
@property (nonatomic, strong) NSArray *buttonTitles;

@property (nonatomic, weak)id <CommonSwitchControlDelegate> delegate;

- (void)initView;

@end
