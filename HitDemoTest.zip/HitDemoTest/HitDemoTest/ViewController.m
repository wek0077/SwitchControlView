//
//  ViewController.m
//  HitDemoTest
//
//  Created by admin on 2018/6/12.
//  Copyright © 2018年 admin. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()<CommonSwitchControlDelegate>


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    CGFloat width = self.view.frame.size.width;
    self.switchView = [[CommonSwitchControl alloc] initWithFrame:CGRectMake(0, 0, width, 66)];
    self.switchView.buttonNumber = 2;
    self.switchView.buttonTitles = @[@"会员统计",@"您的设置"];
    self.switchView.underLineW = 80;
    [self.switchView initView];
    self.switchView.delegate = self;
    [self.view addSubview:self.switchView];
}


- (void)switchButton:(NSInteger )buttonNumber{
    NSLog(@"您选中了%ld",buttonNumber);
}


@end
